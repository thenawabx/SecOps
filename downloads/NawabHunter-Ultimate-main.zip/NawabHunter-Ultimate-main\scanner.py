#!/usr/bin/env python3
import os
import sys
import subprocess
import time
import select
import signal
import json
import glob
import shlex

G, Y, C, M, W, R, B = "\033[92m", "\033[93m", "\033[96m", "\033[95m", "\033[0m", "\033[91m", "\033[1m"

last_interrupt_time = 0
current_step_proc = None
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

def clear_input_buffer():
    try:
        import termios
        termios.tcflush(sys.stdin, termios.TCIFLUSH)
    except Exception:
        while select.select([sys.stdin], [], [], 0.0)[0]:
            sys.stdin.read(1)

def save_progress(progress_file_path, data):
    try:
        with open(progress_file_path, "w") as f:
            json.dump(data, f)
    except Exception:
        pass

def load_progress(progress_file_path):
    if os.path.exists(progress_file_path):
        try:
            with open(progress_file_path, "r") as f:
                return json.load(f)
        except Exception:
            return None
    return None

def clear_progress(progress_file_path):
    if os.path.exists(progress_file_path):
        try:
            os.remove(progress_file_path)
        except Exception:
            pass

def get_nuclei_template_files(template_dir):
    patterns = [
        os.path.join(template_dir, "**", "*.yaml"),
        os.path.join(template_dir, "**", "*.yml")
    ]
    return sorted({path for pattern in patterns for path in glob.glob(pattern, recursive=True)})

def get_all_existing_sessions():
    current_dir = os.getcwd()
    sessions = []
    for item in os.listdir(current_dir):
        if item.startswith("recon_wildcard_") and os.path.isdir(item):
            prog_path = os.path.join(current_dir, item, ".nawab_progress.json")
            if os.path.exists(prog_path):
                data = load_progress(prog_path)
                if data and len(data.get("scanned_indices", [])) > 0:
                    sessions.append({
                        "folder": item,
                        "prog_path": prog_path,
                        "data": data,
                        "target_domain": data.get("target_domain", item.replace("recon_wildcard_", ""))
                    })
    return sessions

def banner():
    os.system('clear')
    print(f"{M}{B}##############################################################")
    print(f"#                                                            #")
    print(f"#   ███╗   ██╗ █████╗ ██╗    ██╗ █████╗ ██████╗              #")
    print(f"#   ████╗  ██║██╔══██╗██║    ██║██╔══██╗██╔══██╗             #")
    print(f"#   ██╔██╗ ██║███████║██║ █╗ ██║███████║██████╔╝             #")
    print(f"#   ██║╚██╗██║██╔══██║██║███╗██║██╔══██║██╔══██╗             #")
    print(f"#   ██║ ╚████║██║  ██║╚███╔███╔╝██║  ██║██████╔╝             #")
    print(f"#   ╚═╝  ╚═══╝╚═╝  ╚═╝ ╚══╝╚══╝ ╚═╝  ╚═╝╚═════╝              #")
    print(f"#                                                            #")
    print(f"#           {Y}NAWAB HUNTER ULTIMATE v0.0.0{M}                     #")
    print(f"#             {C}MODE: ADVANCED RECON & INTEL{M}                   #")
    print(f"##############################################################{W}\n")
    print(f"{G}{B}          --- Welcome to 'thenawabx' world! ---{W}")
    print(f"{R}{B}   >>> PRESS Ctrl+C TO SKIP STEP | DOUBLE PRESS TO EXIT <<<{W}\n")

def setup_alias():
    script_path = os.path.abspath(__file__)
    home = os.path.expanduser("~")
    alias_line = f"alias runawab='python3 {script_path}'"

    for rc_file in [".bashrc", ".zshrc"]:
        path = os.path.join(home, rc_file)
        if os.path.exists(path):
            with open(path, "r") as f:
                content = f.read()
            if alias_line not in content:
                with open(path, "a") as f:
                    f.write(f"\n# Nawab Hunter Alias\n{alias_line}\n")

def handle_interrupt():
    global last_interrupt_time, current_step_proc
    current_time = time.time()
    if current_time - last_interrupt_time < 3:
        print(f"\n{R}[!] Emergency Shutdown Initiated. Exiting...{W}")
        sys.exit(0)
    else:
        last_interrupt_time = current_time
        print(f"\n{Y}[!] Step Skipped. Press again quickly to exit.{W}")
        if current_step_proc:
            try:
                os.killpg(os.getpgid(current_step_proc.pid), signal.SIGTERM)
            except Exception:
                pass

def run_step(name, target_info, cmd):
    global current_step_proc
    print("\n" + "-" * 70)
    print(f"{B}{C}┌──[{W}{M}{name}{W}{B}{C}] Target: {W}{G}{target_info}{W}")
    print(f"{B}{C}└─╼ {W}{Y}[ {cmd} ]{W}\n")

    try:
        current_step_proc = subprocess.Popen(cmd, shell=True, preexec_fn=os.setsid)
        return_code = current_step_proc.wait()
        if return_code == 0:
            print(f"\n{G}{B}[✓] {name} - COMPLETE{W}")
        else:
            print(f"\n{R}{B}[!] {name} - FAILED (exit code {return_code}){W}")
    except KeyboardInterrupt:
        if current_step_proc:
            try:
                os.killpg(os.getpgid(current_step_proc.pid), signal.SIGTERM)
            except Exception:
                pass
        handle_interrupt()
    finally:
        current_step_proc = None
    print("-" * 70 + "\n")

def write_to_master_report(master_file, target, step_label, file_source):
    if os.path.exists(file_source) and os.path.getsize(file_source) > 0:
        with open(master_file, "a") as f_master:
            f_master.write(f"TARGET: {target}\n")
            f_master.write(f"LINK/STEP: {step_label}\n")
            f_master.write("FINDINGS:\n")
            with open(file_source, "r") as f_out:
                f_master.write(f_out.read())
            f_master.write("\n------------------------------------------------------------\n")
        return True
    return False

def configure_tools():
    print(f"\n{C}[=== Tool Configuration Menu ===]{W}")
    print(f"{G}1.{W} RUN ALL TOOLS (httpx-toolkit, Katana, Waybackurls, Nmap, Nuclei)")
    print(f"{G}2.{W} RUN ESSENTIALS (httpx-toolkit, Katana, Nuclei - Recommended)")
    print(f"{G}3.{W} Custom Select (Manually pick each)")
    print(f"{Y}[?] Choice (Default '1' in 15s): {W}", end="", flush=True)

    try:
        rlist, _, _ = select.select([sys.stdin], [], [], 15)
        if rlist:
            choice = sys.stdin.readline().strip().lower()
        else:
            print(f"\n{M}[!] Timeout (15s). Auto-selecting Option 1.{W}")
            choice = "1"
    except Exception:
        choice = "1"

    tools = {'httpx': True, 'katana': True, 'waybackurls': True, 'nmap': True, 'nuclei': True}

    if choice == "2":
        tools['waybackurls'] = False
        tools['nmap'] = False
    elif choice == "3" or choice == "all":
        for tool in tools:
            ans = input(f"{G}Enable {tool}? [y/n]: {W}").lower()
            tools[tool] = (ans != 'n')

    print(f"\n{C}[+] Tool Configuration Saved!{W}\n")
    return tools

def filter_clean_urls(input_file, output_file):
    if not os.path.exists(input_file):
        return
    filtered_lines = []
    skip_exts = (
        '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.css', '.woff', 
        '.woff2', '.ttf', '.eot', '.pdf', '.mp4', '.mp3', '.avi', '.webp', 
        '.bmp', '.swf', '.json', '.xml'
    )
    with open(input_file, "r") as f:
        for line in f:
            l = line.strip()
            if not l:
                continue
            lower_l = l.lower()
            if any(lower_l.split('?')[0].endswith(ext) for ext in skip_exts):
                continue
            filtered_lines.append(l)
    
    with open(output_file, "w") as f:
        f.write("\n".join(filtered_lines) + "\n" if filtered_lines else "")

def filter_router_ips(ip_list):
    """Filter out common router IP ranges and return only real server IPs"""
    router_ranges = [
        ('192.168.0.0', '192.168.255.255'),
        ('10.0.0.0', '10.255.255.255'),
        ('172.16.0.0', '172.31.255.255'),
        ('127.0.0.1', '127.255.255.255'),
        ('169.254.0.0', '169.254.255.255'),
        ('224.0.0.0', '239.255.255.255'),
        ('240.0.0.0', '255.255.255.255'),
    ]
    
    def ip_to_int(ip):
        try:
            parts = [int(p) for p in ip.split('.')]
            return (parts[0] << 24) + (parts[1] << 16) + (parts[2] << 8) + parts[3]
        except:
            return None
    
    def range_to_int(ip):
        return ip_to_int(ip)
    
    def is_private_ip(ip):
        ip_int = ip_to_int(ip)
        if ip_int is None:
            return True
        for start, end in router_ranges:
            start_int = range_to_int(start)
            end_int = range_to_int(end)
            if start_int <= ip_int <= end_int:
                return True
        return False
    
    real_ips = [ip for ip in ip_list if not is_private_ip(ip)]
    return real_ips

def consolidate_subdomain_reports(base_folder, main_report_file):
    """Consolidate all subdomain reports into Vulnerability_Report_CONSOLIDATED.txt"""
    try:
        # Create Consolidated folder if it doesn't exist
        consolidated_folder = os.path.join(base_folder, "Consolidated")
        if not os.path.exists(consolidated_folder):
            os.makedirs(consolidated_folder)
        
        # Update main_report_file path to be inside Consolidated folder
        main_report_file = os.path.join(consolidated_folder, "Vulnerability_Report_CONSOLIDATED.txt")
        
        sub_folders = [d for d in os.listdir(base_folder) if os.path.isdir(os.path.join(base_folder, d)) and d.startswith('sub_')]
        
        if os.path.exists(main_report_file):
            os.remove(main_report_file)
        
        with open(main_report_file, "a") as main_f:
            main_f.write(f"{'='*70}\n")
            main_f.write(f"CONSOLIDATED VULNERABILITY REPORT - Nuclei Findings\n")
            main_f.write(f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            main_f.write(f"{'='*70}\n\n")
        
        for sub_folder in sorted(sub_folders):
            sub_path = os.path.join(base_folder, sub_folder)
            sub_report = os.path.join(sub_path, "Vulnerability_Report.txt")
            
            if os.path.exists(sub_report) and os.path.getsize(sub_report) > 0:
                subdomain_name = sub_folder.replace('sub_', '').replace('_', '.')
                
                with open(main_report_file, "a") as main_f:
                    main_f.write(f"\n{'#'*70}\n")
                    main_f.write(f"# SUBDOMAIN: {subdomain_name}\n")
                    main_f.write(f"{'#'*70}\n\n")
                    
                    with open(sub_report, "r") as sub_f:
                        main_f.write(sub_f.read())
                    
                    main_f.write(f"\n{'#'*70}\n\n")
    except Exception as e:
        print(f"{R}[!] Error consolidating reports: {e}{W}")

def consolidate_url_files(base_folder):
    """Consolidate URL files (Equal_parameters, js_file, api_Information, etc) from all subdomains into Consolidated folder"""
    try:
        # Create Consolidated folder if it doesn't exist
        consolidated_folder = os.path.join(base_folder, "Consolidated")
        if not os.path.exists(consolidated_folder):
            os.makedirs(consolidated_folder)
        
        sub_folders = [d for d in os.listdir(base_folder) if os.path.isdir(os.path.join(base_folder, d)) and d.startswith('sub_')]
        
        # File types to consolidate
        file_types = {
            'Equal_parameters.txt': 'Equal_parameters_CONSOLIDATED.txt',
            'js_file.txt': 'js_file_CONSOLIDATED.txt',
            'api_Information.txt': 'api_Information_CONSOLIDATED.txt',
            'dependency_files.txt': 'dependency_files_CONSOLIDATED.txt',
            'information_Disc.txt': 'information_Disc_CONSOLIDATED.txt'
        }
        
        for original_name, consolidated_name in file_types.items():
            consolidated_file = os.path.join(consolidated_folder, consolidated_name)
            
            # Clear if exists
            if os.path.exists(consolidated_file):
                os.remove(consolidated_file)
            
            # Collect from all subdomains
            for sub_folder in sorted(sub_folders):
                sub_path = os.path.join(base_folder, sub_folder)
                source_file = os.path.join(sub_path, original_name)
                
                if os.path.exists(source_file) and os.path.getsize(source_file) > 0:
                    subdomain_name = sub_folder.replace('sub_', '').replace('_', '.')
                    
                    with open(consolidated_file, "a") as con_f:
                        con_f.write(f"\n{'='*70}\n")
                        con_f.write(f"SUBDOMAIN: {subdomain_name}\n")
                        con_f.write(f"{'='*70}\n")
                        
                        with open(source_file, "r") as src_f:
                            con_f.write(src_f.read())
                        
                        con_f.write(f"\n{'='*70}\n\n")
            
            if os.path.exists(consolidated_file):
                print(f"{G}[+] Consolidated {original_name} >> {consolidated_name}{W}")
    
    except Exception as e:
        print(f"{R}[!] Error consolidating URL files: {e}{W}")

def consolidate_additional_files(base_folder):
    """Consolidate traceroute, nmap, and nuclei result files from all subdomains"""
    try:
        consolidated_folder = os.path.join(base_folder, "Consolidated")
        if not os.path.exists(consolidated_folder):
            os.makedirs(consolidated_folder)
        
        sub_folders = [d for d in os.listdir(base_folder) if os.path.isdir(os.path.join(base_folder, d)) and d.startswith('sub_')]
        
        # Consolidate traceroute IPs
        traceroute_consolidated = os.path.join(consolidated_folder, "traceroute_ips_CONSOLIDATED.txt")
        if os.path.exists(traceroute_consolidated):
            os.remove(traceroute_consolidated)
        
        for sub_folder in sorted(sub_folders):
            sub_path = os.path.join(base_folder, sub_folder)
            traceroute_file = os.path.join(sub_path, "traceroute_ips.txt")
            
            if os.path.exists(traceroute_file) and os.path.getsize(traceroute_file) > 0:
                subdomain_name = sub_folder.replace('sub_', '').replace('_', '.')
                with open(traceroute_consolidated, "a") as con_f:
                    con_f.write(f"\n{'='*70}\n")
                    con_f.write(f"SUBDOMAIN: {subdomain_name}\n")
                    con_f.write(f"{'='*70}\n")
                    with open(traceroute_file, "r") as src_f:
                        con_f.write(src_f.read())
                    con_f.write(f"\n{'='*70}\n\n")
        
        if os.path.exists(traceroute_consolidated):
            print(f"{G}[+] Consolidated traceroute_ips.txt >> traceroute_ips_CONSOLIDATED.txt{W}")
        
        # Consolidate Nmap Results
        nmap_consolidated = os.path.join(consolidated_folder, "nmap_result_CONSOLIDATED.txt")
        if os.path.exists(nmap_consolidated):
            os.remove(nmap_consolidated)
        
        for sub_folder in sorted(sub_folders):
            sub_path = os.path.join(base_folder, sub_folder)
            nmap_file = os.path.join(sub_path, "nmap_result.txt")
            
            if os.path.exists(nmap_file) and os.path.getsize(nmap_file) > 0:
                subdomain_name = sub_folder.replace('sub_', '').replace('_', '.')
                with open(nmap_consolidated, "a") as con_f:
                    con_f.write(f"\n{'='*70}\n")
                    con_f.write(f"SUBDOMAIN: {subdomain_name}\n")
                    con_f.write(f"{'='*70}\n")
                    with open(nmap_file, "r") as src_f:
                        con_f.write(src_f.read())
                    con_f.write(f"\n{'='*70}\n\n")
        
        if os.path.exists(nmap_consolidated):
            print(f"{G}[+] Consolidated nmap_result.txt >> nmap_result_CONSOLIDATED.txt{W}")
        
        # Consolidate Nuclei Results
        nuclei_consolidated = os.path.join(consolidated_folder, "nuclei_CONSOLIDATED.txt")
        if os.path.exists(nuclei_consolidated):
            os.remove(nuclei_consolidated)
        
        for sub_folder in sorted(sub_folders):
            sub_path = os.path.join(base_folder, sub_folder)
            subdomain_name = sub_folder.replace('sub_', '').replace('_', '.')
            
            # Find all nuclei_*.txt files in subdomain folder
            nuclei_files = [f for f in os.listdir(sub_path) if f.startswith('nuclei_') and f.endswith('.txt')]
            
            if nuclei_files:
                with open(nuclei_consolidated, "a") as con_f:
                    con_f.write(f"\n{'='*70}\n")
                    con_f.write(f"SUBDOMAIN: {subdomain_name}\n")
                    con_f.write(f"{'='*70}\n")
                    
                    for nuclei_file in sorted(nuclei_files):
                        nuclei_path = os.path.join(sub_path, nuclei_file)
                        if os.path.getsize(nuclei_path) > 0:
                            con_f.write(f"\n[{nuclei_file}]\n")
                            con_f.write(f"{'-'*70}\n")
                            with open(nuclei_path, "r") as src_f:
                                con_f.write(src_f.read())
                            con_f.write(f"\n{'-'*70}\n")
                    
                    con_f.write(f"\n{'='*70}\n\n")
        
        if os.path.exists(nuclei_consolidated):
            print(f"{G}[+] Consolidated nuclei_*.txt >> nuclei_CONSOLIDATED.txt{W}")
    
    except Exception as e:
        print(f"{R}[!] Error consolidating additional files: {e}{W}")

def process_single_recon(target, extra_flags, parent_dir, master_vuln_file, tools):
    clean_target = target.replace('https://', '').replace('http://', '').strip('/')
    folder_name = f"sub_{clean_target.replace('.', '_')}"
    sub_path = os.path.join(parent_dir, folder_name)

    if not os.path.exists(sub_path):
        os.makedirs(sub_path)

    orig_dir = os.getcwd()
    os.chdir(sub_path)

    t_path = os.path.join(SCRIPT_DIR, "Nuclei_Templates")

    if tools.get('httpx', True):
        run_step("POINT 1: Live Probing", clean_target, f"echo {clean_target} | httpx-toolkit {extra_flags} -o live_sub.txt")

    if tools.get('katana', True):
        run_step("POINT 2: Katana Crawling", clean_target, f"katana -u {clean_target} -rl 10 -o katana_urls.txt")

    if tools.get('waybackurls', True):
        run_step("POINT 3: Wayback URLs", clean_target, f"echo {clean_target} | waybackurls | tee wayback_urls.txt")

    run_step("POINT 4: Smart Intel & Parameter Filtering", clean_target,
           f"cat wayback_urls.txt katana_urls.txt 2>/dev/null | sort -u > all_urls.txt; "
           f"grep '=' all_urls.txt > Equal_parameters.txt; "
           f"grep '\\.js' all_urls.txt > js_file.txt; "
           f"grep 'api' all_urls.txt > api_Information.txt; "
           f"grep -E 'package\\.json|composer\\.json|requirements\\.txt' all_urls.txt > dependency_files.txt; "
           f"grep -E '.env|.log|.sql|.conf' all_urls.txt > information_Disc.txt")

    filter_clean_urls("all_urls.txt", "filtered_clean_urls.txt")

    run_step("POINT 4.1: PAC & Config Detection", clean_target,
           f"grep -iE '\\.pac|\\.conf|\\.config' all_urls.txt > pac_config_files.txt; "
           f"if [ -s pac_config_files.txt ]; then "
           f"cat pac_config_files.txt | xargs -I{{}} curl -s -k \"{{}}\" | grep -iE 'FindProxyForURL|PROXY|DIRECT' > proxy_pac_findings.txt; "
           f"fi")

    run_step("POINT 4.2: JS Secrets Extraction", clean_target,
           f"if [ -s js_file.txt ]; then "
           f"cat js_file.txt | httpx-toolkit -silent | mantra -s > js_secrets.txt 2>/dev/null; "
           f"fi")

    run_step("POINT 4.3: Traceroute & IP Range Expansion", clean_target,
           f"traceroute -n {clean_target} 2>/dev/null | grep -E -o '([0-9]{{1,3}}\\.)[0-9]{{1,3}}\\.[0-9]{{1,3}}\\.[0-9]{{1,3}}' | sort -u > traceroute_ips.txt")

    if tools.get('nmap', True):
        run_step("POINT 4.4: Filter Real IPs & Nmap Scan on Traceroute Results", clean_target,
           f"if [ -s traceroute_ips.txt ]; then "
           f"echo '========================================' > nmap_result.txt; "
           f"echo 'NMAP SCAN RESULTS - Traceroute IPs' >> nmap_result.txt; "
           f"echo '========================================' >> nmap_result.txt; "
           f"while read ip; do "
           f"echo '' >> nmap_result.txt; "
           f"echo '========================================' >> nmap_result.txt; "
           f"echo \"IP: $ip\" >> nmap_result.txt; "
           f"echo '========================================' >> nmap_result.txt; "
           f"nmap -Pn -n -sV --top-ports 100 --open -T4 \"$ip\" >> nmap_result.txt 2>&1; "
           f"echo '========================================' >> nmap_result.txt; "
           f"done < traceroute_ips.txt; "
           f"else "
           f"echo 'No real IPs found in traceroute' > nmap_result.txt; "
           f"fi")

    found_in_target = False
    if tools.get('nuclei', True):
        template_files = get_nuclei_template_files(t_path)
        if not os.path.isdir(t_path):
            print(f"{R}[!] Nuclei template directory not found: {t_path}{W}")
            tools['nuclei'] = False
        elif not template_files:
            print(f"{R}[!] No Nuclei YAML templates found in: {t_path}{W}")
            tools['nuclei'] = False
        else:
            print(f"{G}[+] Loaded {len(template_files)} Nuclei templates from: {t_path}{W}")

    if tools.get('nuclei', True):
        nuclei_base = f"nuclei -t {shlex.quote(t_path)} -severity low,medium,high,critical -stats -rl 6 -c 3 {extra_flags}"

        n_tasks = [
            ("POINT 5: Nuclei (Dependency Confusion Check)", "dependency_files.txt", "nuclei_dependency.txt"),
            ("POINT 6: Nuclei (JS Intel)", "js_file.txt", "nuclei_js.txt"),
            ("POINT 7: Nuclei (API Intel)", "api_Information.txt", "nuclei_api.txt"),
            ("POINT 8: Nuclei (Info Disclosure)", "information_Disc.txt", "nuclei_info.txt"),
            ("POINT 9: Nuclei (LFI Check)", "Equal_parameters.txt", "nuclei_lfi.txt"),
            ("POINT 10: Nuclei (Sensitive Backup Check)", "filtered_clean_urls.txt", "nuclei_backup.txt")
        ]

        for label, src, out in n_tasks:
            if os.path.exists(src) and os.path.getsize(src) > 0:
                run_step(label, clean_target, f"{nuclei_base} -l {src} -o {out}")
                if write_to_master_report(master_vuln_file, clean_target, label, out):
                    found_in_target = True

    print("\n" + "="*60)
    os.chdir(orig_dir)

    if found_in_target:
        print(f"{G}{B}[+] INTEL / ASSETS FOUND on {clean_target}! Check Report: {master_vuln_file}{W}")
    else:
        print(f"{R}{B}[!] NO SIGNIFICANT INTEL FOUND on {clean_target}.{W}")
    print("="*60 + "\n")

def process_single_domain_mode(target_list, extra_flags, root_dir, tools):
    recon_folder = os.path.abspath("recon_single_targets")
    if not os.path.exists(recon_folder):
        os.makedirs(recon_folder)
    
    main_consolidated_report = os.path.join(recon_folder, "Vulnerability_Report_CONSOLIDATED.txt")
    
    # Clear previous consolidated report
    if os.path.exists(main_consolidated_report):
        os.remove(main_consolidated_report)
    
    for target in target_list:
        clean_target = target.replace('https://', '').replace('http://', '').strip('/')
        folder_name = f"sub_{clean_target.replace('.', '_')}"
        abs_folder = os.path.abspath(os.path.join(recon_folder, folder_name))
        if not os.path.exists(abs_folder):
            os.makedirs(abs_folder)
        master_vuln_file = os.path.join(abs_folder, "Vulnerability_Report.txt")
        print(f"\n{G}[+] Processing Single Domain: {target}{W}")
        process_single_recon(target, extra_flags, recon_folder, master_vuln_file, tools)
    
    print(f"\n{C}[*] Consolidating all domain vulnerabilities into Consolidated folder...{W}")
    consolidate_subdomain_reports(recon_folder, main_consolidated_report)
    print(f"{G}[+] Consolidated vulnerability report saved to: Consolidated/Vulnerability_Report_CONSOLIDATED.txt{W}")
    
    print(f"\n{C}[*] Consolidating all URL files from domains...{W}")
    consolidate_url_files(recon_folder)
    print(f"{G}[+] URL files consolidated in Consolidated/ folder!{W}")
    
    print(f"\n{C}[*] Consolidating traceroute, nmap, and nuclei results...{W}")
    consolidate_additional_files(recon_folder)
    print(f"{G}[+] Additional files consolidated in Consolidated/ folder!{W}")

def process_wildcard(domain, extra_flags, root_dir, tools, resume_indices=None):
    base_folder = f"recon_wildcard_{domain.replace('.', '_')}"
    if not os.path.exists(base_folder):
        os.makedirs(base_folder)

    abs_base = os.path.abspath(base_folder)
    master_vuln_file = os.path.join(abs_base, "Vulnerability_Report.txt")
    main_consolidated_report = os.path.join(abs_base, "Vulnerability_Report_CONSOLIDATED.txt")
    progress_file_path = os.path.join(abs_base, ".nawab_progress.json")

    orig_dir = os.getcwd()
    os.chdir(abs_base)

    if not os.path.exists("live_sub.txt") or os.path.getsize("live_sub.txt") == 0:
        run_step("POINT 1: Subdomain Enumeration", domain,
                 f"subfinder -d {domain} -o subfinder.txt; "
                 f"assetfinder --subs-only {domain} | tee assetfinder.txt;")

        run_step("POINT 2: Merge & Unique", domain, f"cat subfinder.txt assetfinder.txt 2>/dev/null | sort -u > all_subs.txt")
        run_step("POINT 3: DNS Resolution", domain, f"dnsx -l all_subs.txt {extra_flags} -o dnsx_resolved.txt")
        run_step("POINT 4: Web Probing", domain, f"cat dnsx_resolved.txt | httpx-toolkit -o live_sub.txt")
    else:
        print(f"\n{G}[+] Existing 'live_sub.txt' found. Skipping Subdomain Enumeration!{W}\n")

    scanned_indices = set(resume_indices) if resume_indices is not None else set()
    save_progress(progress_file_path, {
        "mode": "1",
        "target_domain": domain,
        "scanned_indices": list(scanned_indices)
    })

    if os.path.exists("live_sub.txt") and os.path.getsize("live_sub.txt") > 0:
        with open("live_sub.txt", "r") as f:
            domains = [l.strip().replace('https://', '').replace('http://', '').strip('/') for l in f if l.strip()]

        while len(scanned_indices) < len(domains):
            clear_input_buffer()

            print(f"\n{G}[+] Remaining Active Targets ({len(domains) - len(scanned_indices)} left):{W}")
            available_this_round = False
            for idx, d in enumerate(domains):
                if idx not in scanned_indices:
                    print(f"{C}{idx + 1}.{W} {d}")
                    available_this_round = True

            if not available_this_round:
                break

            print(f"\n{Y}[?] Enter numbers (e.g: 1,2,5), '3' (All), or wait [Auto-Next in 15s]: {W}", end="", flush=True)

            is_auto_select = False
            try:
                rlist, _, _ = select.select([sys.stdin], [], [], 15)
                if rlist:
                    choice = sys.stdin.readline().strip().lower()
                else:
                    is_auto_select = True
                    choice = ""
            except Exception:
                is_auto_select = True
                choice = ""

            if choice == 'exit':
                break

            targets_to_scan = []

            if is_auto_select:
                for idx, d in enumerate(domains):
                    if idx not in scanned_indices:
                        targets_to_scan = [(idx, d)]
                        print(f"\n{M}[!] Timeout (15s). Auto-selecting next target: {C}{d}{W}")
                        break
            elif choice == '3' or choice == 'all':
                targets_to_scan = [(idx, d) for idx, d in enumerate(domains) if idx not in scanned_indices]
            else:
                try:
                    indices = [int(x.strip()) - 1 for x in choice.split(',')]
                    for i in indices:
                        if 0 <= i < len(domains) and i not in scanned_indices:
                            targets_to_scan.append((i, domains[i]))
                    if not targets_to_scan:
                        targets_to_scan = [(idx, domains[idx]) for idx in range(len(domains)) if idx not in scanned_indices]
                except ValueError:
                    print(f"{R}[!] Invalid input. Defaulting to auto-select next.{W}")
                    for idx, d in enumerate(domains):
                        if idx not in scanned_indices:
                            targets_to_scan = [(idx, d)]
                            break

            for idx, t in targets_to_scan:
                process_single_recon(t, extra_flags, abs_base, master_vuln_file, tools)
                scanned_indices.add(idx)

                save_progress(progress_file_path, {
                    "mode": "1",
                    "target_domain": domain,
                    "scanned_indices": list(scanned_indices)
                })

    clear_progress(progress_file_path)
    
    print(f"\n{C}[*] Consolidating all subdomain vulnerabilities into Consolidated folder...{W}")
    consolidate_subdomain_reports(abs_base, main_consolidated_report)
    print(f"{G}[+] Consolidated vulnerability report saved to: Consolidated/Vulnerability_Report_CONSOLIDATED.txt{W}")
    
    print(f"\n{C}[*] Consolidating all URL files from subdomains...{W}")
    consolidate_url_files(abs_base)
    print(f"{G}[+] URL files consolidated in Consolidated/ folder!{W}")
    
    print(f"\n{C}[*] Consolidating traceroute, nmap, and nuclei results...{W}")
    consolidate_additional_files(abs_base)
    print(f"{G}[+] Additional files consolidated in Consolidated/ folder!{W}")
    
    os.chdir(orig_dir)

def main():
    setup_alias()
    os.chdir(SCRIPT_DIR)
    banner()
    root_dir = SCRIPT_DIR
    extra_flags = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else ""

    tools = configure_tools()

    existing_sessions = get_all_existing_sessions()
    run_mode_choice = "1"

    if existing_sessions:
        print(f"\n{Y}[!] Found {len(existing_sessions)} unfinished session(s) in current directory:{W}")
        for idx, sess in enumerate(existing_sessions):
            print(f"  {G}{idx + 1}.{W} Folder: {C}{sess['folder']}{W} | Target: {C}{sess['target_domain']}{W} (Scanned: {len(sess['data'].get('scanned_indices', []))} targets)")
        
        print(f"\n{C}Do you want to resume an existing session or start fresh?{W}")
        print(f"{G}1.{W} Resume an existing session")
        print(f"{G}2.{W} Start a brand new scan (New Domain / Wildcard)")
        print(f"{Y}[?] Choice [Default '1' in 15s]: {W}", end="", flush=True)

        try:
            rlist, _, _ = select.select([sys.stdin], [], [], 15)
            choice = sys.stdin.readline().strip() if rlist else "1"
        except Exception:
            choice = "1"

        if choice == "2":
            print(f"\n{M}[+] Starting a brand new scan...{W}")
        else:
            if len(existing_sessions) == 1:
                selected_sess = existing_sessions[0]
                print(f"\n{G}[+] Resuming session for: {selected_sess['target_domain']}{W}")
                process_wildcard(selected_sess['target_domain'], extra_flags, root_dir, tools, resume_indices=selected_sess['data'].get("scanned_indices", []))
                return
            else:
                print(f"\n{Y}[?] Enter the number of the session you want to resume (1-{len(existing_sessions)}): {W}", end="")
                try:
                    sess_choice = int(sys.stdin.readline().strip()) - 1
                    if 0 <= sess_choice < len(existing_sessions):
                        selected_sess = existing_sessions[sess_choice]
                        print(f"\n{G}[+] Resuming session for: {selected_sess['target_domain']}{W}")
                        process_wildcard(selected_sess['target_domain'], extra_flags, root_dir, tools, resume_indices=selected_sess['data'].get("scanned_indices", []))
                        return
                    else:
                        print(f"{R}[!] Invalid selection. Starting new scan instead.{W}")
                except Exception:
                    print(f"{R}[!] Invalid input. Starting new scan instead.{W}")

    clear_input_buffer()
    print(f"\n{C}{B}Select Operation Mode:{W}")
    print(f"{G}1.{W} Wildcard Mode (Multi Deep Recon / Subdomains)")
    print(f"{G}2.{W} Domain Mode (Single Deep Recon - Comma separated)")
    print(f"{C}{B}└─╼ {W}{Y}Choice [Default '1' in 15s] {B}{C}>> {W}", end="", flush=True)

    try:
        rlist, _, _ = select.select([sys.stdin], [], [], 15)
        if rlist:
            mode = sys.stdin.readline().strip()
        else:
            print(f"\n{M}[!] Timeout. Selecting default Mode 1...{W}")
            mode = "1"
    except Exception:
        mode = "1"

    clear_input_buffer()
    print(f"\n{Y}[?] Enter Target(s) Here (comma separated for multiple): {W}", end="")

    try:
        user_input = sys.stdin.readline().strip()
        if not user_input:
            return
        targets = [t.strip() for t in user_input.split(',')]

        if mode == "2":
            process_single_domain_mode(targets, extra_flags, root_dir, tools)
        else:
            for t in targets:
                print(f"\n{G}[+] Processing Wildcard Domain: {t}{W}")
                process_wildcard(t, extra_flags, root_dir, tools)

    except KeyboardInterrupt:
        handle_interrupt()

if __name__ == '__main__':
    main()
